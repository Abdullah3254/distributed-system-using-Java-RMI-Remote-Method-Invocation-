import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class ResourceServer {
    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099);
            ResourceManager resourceManager = new ResourceManagerImpl();
            Naming.rebind("rmi://localhost/ResourceManager", resourceManager);
            System.out.println("ResourceManager is ready.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
