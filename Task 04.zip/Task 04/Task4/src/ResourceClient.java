import java.rmi.Naming;

public class ResourceClient {
    public static void main(String[] args) {
        try {
            ResourceManager resourceManager = (ResourceManager) Naming.lookup("rmi://localhost/ResourceManager");
            resourceManager.addResource("exampleResource", "This is an example resource.");
            String resource = resourceManager.getResource("exampleResource");
            System.out.println("Resource value: " + resource);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
